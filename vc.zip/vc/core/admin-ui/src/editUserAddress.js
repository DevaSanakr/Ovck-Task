import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom';
import SuccessModel from './components/successModel';

function EditUserAddress() {
    const [userDetail, setuserDetail] = useState({});
    let { id } = useParams();
    const handleChange = (e) => {
        let userData = { ...userDetail };
        userData['address'][e.target.name] = e.target.value;
        setuserDetail(userData);
        console.log(userData)
    }
    const fetchUser = async () => {
        axios.get(`${process.env.REACT_APP_API_URL}/api/v1/auth/admin/user/${id}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "ngrok-skip-browser-warning": true,
                "Access-Control-Allow-Origin": "*"
            }
        }).then((user) => { setuserDetail(user.data.user); });
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log('The form was submitted: ', userDetail);
        axios.put(`${process.env.REACT_APP_API_URL}/api/v1/auth/admin/user/${id}`, userDetail)
            .then((res) => {
                console.log(res);
                document.getElementById('successBtn').click();
            }).catch(e => console.log(e))
    }
    useEffect(() => {
        if (Object.entries(userDetail).keys.length === 0) { fetchUser() };
        // eslint-disable-next-line
    }, [])
    return (
        <>
            <div className="row">
                <div className="col-lg-12 mb-4">
                    <div className="card">
                        <div className="card-body">
                            <h5 className="mb-3 card-title">Edit User Address</h5>
                            <form onSubmit={(e) => { handleSubmit(e) }}>
                                <div className="mb-3">
                                    <label htmlFor="buildingName" className="form-label">Building Name</label>
                                    <input
                                        className="form-control"
                                        type="text"
                                        id="buildingName"
                                        name="buildingName"
                                        value={userDetail ? userDetail?.address?.buildingName : ""}
                                        onChange={(e) => { handleChange(e) }}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="street" className="form-label">Street</label>
                                    <input
                                        className="form-control"
                                        type="text"
                                        id="street"
                                        name="street"
                                        value={userDetail ? userDetail?.address?.street : ""}
                                        onChange={(e) => { handleChange(e) }}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="area" className="form-label">area</label>
                                    <input
                                        className="form-control"
                                        type="text"
                                        id="area"
                                        name="area"
                                        value={userDetail ? userDetail?.address?.area : ""}
                                        onChange={(e) => { handleChange(e) }}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="city" className="form-label">city</label>
                                    <input
                                        className="form-control"
                                        type="text"
                                        id="city"
                                        name="city"
                                        value={userDetail ? userDetail?.address?.city : ""}
                                        onChange={(e) => { handleChange(e) }}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="state" className="form-label">state</label>
                                    <input
                                        className="form-control"
                                        type="text"
                                        id="state"
                                        name="state"
                                        value={userDetail ? userDetail?.address?.state : ""}
                                        onChange={(e) => { handleChange(e) }}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="country" className="form-label">country</label>
                                    <input
                                        className="form-control"
                                        type="text"
                                        id="country"
                                        name="country"
                                        value={userDetail ? userDetail?.address?.country : ""}
                                        onChange={(e) => { handleChange(e) }}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="pincode" className="form-label">pincode</label>
                                    <input
                                        className="form-control"
                                        type="text"
                                        id="pincode"
                                        name="pincode"
                                        value={userDetail ? userDetail?.address?.pincode : ""}
                                        onChange={(e) => { handleChange(e) }}
                                    />
                                </div>
                                <div className='text-end'>
                                    <button className='btn btn-primary' type='submit'>Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <button type="button" className="d-none" id='successBtn' data-bs-toggle="modal" data-bs-target="#successModal"></button>
            <SuccessModel message={'Updated successfully!'} />
        </>
    )
}

export default EditUserAddress;

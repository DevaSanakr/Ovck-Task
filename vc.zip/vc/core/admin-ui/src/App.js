import { BrowserRouter as Router, Route, Routes, Outlet } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';

import Header from './components/header'
// import Footer from './components/footer'
import Sidebar from './components/sidebar'
import Dashboard from './dashboard'
import UserList from './userList';
import UserDetail from './userDetail';
import EditUserDetail from './editUserDetail';
import EditUserAddress from './editUserAddress';

const CreateResumeLayout = ({ children, ...rest }) => {
  return (
    <>
    <div className="layout-wrapper layout-content-navbar">
        <div className="layout-container">
          <Sidebar />
          <div className="layout-page">
            <Header />
            <div className="content-wrapper">
              <div className="container-xxl flex-grow-1 container-p-y">
                {/* <Dashboard /> */}
                <Outlet />
                {/* <Footer /> */}
                <div className="content-backdrop fade"></div>
              </div>
            </div>
          </div>
          <div className="layout-overlay layout-menu-toggle"></div>
        </div>
      </div>
    </>
  )
}
function App() {
  return (
    <>

      

      <Router>
        <div className="bg-white">
          <HelmetProvider>
            <Routes>
              <Route exact path="/" element={<CreateResumeLayout />} >
                <Route exact path="/dashboard" element={<Dashboard />} />
                <Route exact path="/userlist" element={<UserList />} />
                <Route exact path="/userdetail/:id" element={<UserDetail />} />
                <Route exact path="/editUserDetail/:id" element={<EditUserDetail />} />
                <Route exact path="/editUserAddress/:id" element={<EditUserAddress />} />
              </Route>

              {/* <Route path='/admin/dashboard' element={<ProtectedRoute isAdmin={true}><Dashboard /></ProtectedRoute>} />
              <Route path='/admin/products' element={<ProtectedRoute isAdmin={true}><ProductList /></ProtectedRoute>} />
              <Route path='/admin/products/create' element={<ProtectedRoute isAdmin={true}><NewProduct /></ProtectedRoute>} />
              <Route path='/admin/product/:id' element={<ProtectedRoute isAdmin={true}><UpdateProduct /></ProtectedRoute>} />
              <Route path='/admin/orders' element={<ProtectedRoute isAdmin={true}><OrderList /></ProtectedRoute>} />
              <Route path='/admin/order/:id' element={<ProtectedRoute isAdmin={true}><UpdateOrder /></ProtectedRoute>} />
              <Route path='/admin/users' element={<ProtectedRoute isAdmin={true}><UserList /></ProtectedRoute>} />
              <Route path='/admin/user/:id' element={<ProtectedRoute isAdmin={true}><UpdateUser /></ProtectedRoute>} />
              <Route path='/admin/reviews' element={<ProtectedRoute isAdmin={true}><ReviewList /></ProtectedRoute>} /> */}
            </Routes>
          </HelmetProvider>
        </div>
      </Router>
    </>
  );
}

export default App;

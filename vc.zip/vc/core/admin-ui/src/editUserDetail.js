import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom';
import SuccessModel from './components/successModel';

function EditUserDetail() {
    const [userDetail, setuserDetail] = useState({});
    const [role, setRole] = useState([]);
    let { id } = useParams();
    const handleChange = (e) => {
        let userData = { ...userDetail };
        userData[e.target.name] = e.target.value;
        setuserDetail(userData);
    }
    const fetchUser = async () => {
        axios.get(`${process.env.REACT_APP_API_URL}/api/v1/auth/admin/user/${id}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "ngrok-skip-browser-warning": true,
                "Access-Control-Allow-Origin": "*"
            }
        }).then((user) => { setuserDetail(user.data.user); });
    }
    const fetchRole = async () => {
        axios.get(`${process.env.REACT_APP_API_URL}/api/v1/auth/role/`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "ngrok-skip-browser-warning": true,
                "Access-Control-Allow-Origin": "*"
            }
        }).then((user) => { setRole(user.data.role); });
    }
    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log('The form was submitted: ', userDetail);
        await axios.put(`${process.env.REACT_APP_API_URL}/api/v1/auth/admin/user/${id}`, userDetail)
            .then((res) => {
                console.log(res);
                document.getElementById('successBtn').click();
            }).catch(e=>console.log(e))
    }
    useEffect(() => {
        if (Object.entries(userDetail).keys.length === 0) { fetchUser() };
        if (Object.entries(role).keys.length === 0) { fetchRole() };
        // eslint-disable-next-line
    }, [])
    return (
        <>
            <div className="row">
                <div className="col-lg-12 mb-4">
                    <div className="card">
                        <div className="card-body">
                            <h5 className="mb-3 card-title">Edit User Details</h5>
                            <form onSubmit={(e) => { handleSubmit(e) }}>
                                <div className="mb-3">
                                    <label htmlFor="name" className="form-label">Name</label>
                                    <input
                                        className="form-control"
                                        type="text"
                                        id="name"
                                        name="name"
                                        value={userDetail ? userDetail.name : ""}
                                        onChange={(e) => { handleChange(e) }}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="email" className="form-label">Email</label>
                                    <input
                                        className="form-control"
                                        type="email"
                                        id="email"
                                        name="email"
                                        value={userDetail ? userDetail.email : ""}
                                        onChange={(e) => { handleChange(e) }}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="mobile" className="form-label">Mobile</label>
                                    <input
                                        className="form-control"
                                        type="text"
                                        id="mobile"
                                        name="mobile"
                                        value={userDetail ? userDetail.mobile : ""}
                                        onChange={(e) => { handleChange(e) }}
                                    />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="role" className="form-label">Role</label>

                                    <select id="role" name="role" className="form-select form-select-sm"
                                        value={userDetail ? userDetail?.role?._id : ""}
                                        onChange={(e) => { handleChange(e) }}
                                    >
                                        <option selected >Select Role...</option>
                                        {role && role.map((r) => (
                                            <option key={r._id} value={r._id}>{r.name.toUpperCase()}</option>
                                        ))}
                                    </select>
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="isActive" className="form-label">Active</label>
                                    <div className="form-check">
                                        <input className="form-check-input" name='isActive' type="checkbox"
                                            checked={userDetail?.isActive === true || false}
                                            onChange={(e) => setuserDetail({ ...userDetail, isActive: !userDetail.isActive })}
                                            id="isActive" />
                                    </div>
                                </div>
                                <div className='text-end'>
                                    <button className='btn btn-primary' type='submit'>Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <button type="button" className="d-none" id='successBtn' data-bs-toggle="modal" data-bs-target="#successModal"></button>
            <SuccessModel message={'Updated successfully!'}/>
        </>
    )
}

export default EditUserDetail;

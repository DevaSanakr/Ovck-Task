import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import DeleteModel from './components/deleteModel';
import BreadCrumb from './components/breadCrumb';

function UserList() {
    const [data, setData] = useState([]);
    const [userId, setUserId] = useState(null);
    let navigate = useNavigate();
    useEffect(() => {
        if(data.length === 0){ fetchUsers()};
        // eslint-disable-next-line
    }, [])
    const fetchUsers = async () => {
        axios.get(`${process.env.REACT_APP_API_URL}/api/v1/auth/admin/users/`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "ngrok-skip-browser-warning": true,
                "Access-Control-Allow-Origin": "*"
            }
        }).then((user) => { setData(user.data.users); console.log("userData", user.data.users) });
    }
    const handleDeleteUser = (id)=>{
        setUserId(id)
        document.getElementById('deleteBtn').click();
    }
    const handleEditUser = (id)=>{
        navigate("/editUserDetail/"+ id)
    }
    const handleRedirect = (id)=>{
        navigate("/userdetail/"+ id)
    }
        
    const NAVS = [
        {
          title: "Dashboard",
          link: `/dashboard`
        },
        {
          title: "User",
          link: `/userlist`
        },
        { title: 'User List', link: '/userlist' }
      ];

    return (
        <>
            <BreadCrumb navigation= {NAVS} /> 
            <div className="row">
                <div className="col-lg-12 mb-4">
                    <div className="card">
                        <h5 className="card-header">User List</h5>
                        <div className="card-body">
                            <div className="table-responsive text-nowrap">
                                <table className="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Mobile</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody className='border-top-0'>
                                        {data && data.map((item, index) => (
                                            <tr key={index}>
                                                <td>{item._id}</td>
                                                <td>{item.name}</td>
                                                <td>{item.email}</td>
                                                <td>{item.mobile}</td>
                                                <td>
                                                    <button onClick={() => handleRedirect(item._id)} type="button" className="btn btn-outline-info btn-sm">
                                                        <i className='bi bi-eye'></i>
                                                    </button>
                                                    <button onClick={() => handleEditUser(item._id)} type="button" className="btn btn-outline-primary btn-sm ms-2">
                                                        <i className='bi bi-pencil'></i>
                                                    </button>
                                                    <button onClick={() => handleDeleteUser(item._id)} type="button" className="btn btn-outline-danger btn-sm ms-2">
                                                        <i className='bi bi-trash'></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button type="button" className="d-none" id='deleteBtn' data-bs-toggle="modal" data-bs-target="#deleteModal"></button>
            <DeleteModel id={userId}/>
        </>
    )
};

export default UserList

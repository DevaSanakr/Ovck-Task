import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import avatar from './assets/avatar/avatar-1.png';
function UserList() {
    const [data, setData] = useState([]);
    const [userImage, setUserImage] = useState(avatar);
    const [imageFile, setImageFile] = useState(null);
    let navigate = useNavigate();
    useEffect(() => {
        if (data.length === 0) { fetchUser() };
        // eslint-disable-next-line
    }, [])
    let { id } = useParams();
    const fetchUser = async () => {
        axios.get(`${process.env.REACT_APP_API_URL}/api/v1/auth/admin/user/${id}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "ngrok-skip-browser-warning": true,
                "Access-Control-Allow-Origin": "*"
            }
        }).then((user) => { setData(user.data.user); console.log(user.data.user) });
    }
    const handleImage = (event) => {
        console.log(event.target.files[0])
        if (event.target.files[0]) {
            setUserImage(window.URL.createObjectURL(event.target.files[0]));
            setImageFile(event.target.files[0]);
        }

    }
    const handleSubmit = async () => {
        var formData=new FormData();
        formData.append("avatar", imageFile);
        console.log("-----", imageFile)
        await axios.put(`${process.env.REACT_APP_API_URL}/api/v1/auth/admin/user/${id}`,formData ).then((res) => {
            console.log(res);
            // document.getElementById('successBtn').click();
        }).catch(e => console.log(e))
    }
    const handleRedirct = (url) => {
        navigate(`/${url}/` + id)
    }

    return (
        <>
            <div className="row">
                <div className="col-lg-12 mb-4">
                    <div className="card">
                        <div className="card-body">
                            <div className="d-flex align-items-center justify-content-center align-items-sm-center gap-4">
                                <div className='d-flex align-items-center justify-content-center flex-column'>
                                    <img
                                        src={userImage}
                                        alt="user-avatar"
                                        className="d-block rounded mb-3"
                                        height="100"
                                        width="100"
                                        id="uploadedAvatar"
                                    />
                                    <div className="button-wrapper text-center">
                                        <label htmlFor="upload" className="btn btn-primary me-2 mb-2" tabIndex="0">
                                            <span className="d-none d-sm-block">Upload new photo</span>
                                            <i className="bx bx-upload d-block d-sm-none"></i>
                                            <input
                                                type="file"
                                                id="upload"
                                                className="account-file-input"
                                                hidden
                                                accept="image/png, image/jpeg"
                                                onChange={(e) => handleImage(e)}
                                            />
                                        </label>
                                        <button className="btn btn-primary mb-2" type='button' onClick={() => handleSubmit()}>Submit</button>
                                        {/* <button type="button" className="btn btn-outline-secondary account-image-reset mb-2">
                                        <i className="bx bx-reset d-block d-sm-none"></i>
                                        <span className="d-none d-sm-block">Reset</span>
                                    </button> */}

                                        <p className="text-muted mb-0">Allowed JPG, GIF or PNG. Max size of 800K</p>
                                    </div>
                                </div>
                            </div>
                            {data &&
                                (
                                    <div className='row align-items-center justify-content-center mt-4'>
                                        <div className='col-md-8'>
                                            <div className='d-flex justify-content-between align-items-center my-3'>
                                                <h5 className=''>Profile</h5>
                                                <button onClick={() => { handleRedirct('editUserDetail') }} className='btn btn-outline-primary btn-sm'>
                                                    <i className='bi bi-pencil'></i> Edit
                                                </button>
                                            </div>
                                            <div className='table-responsive'>
                                                <table className='table table-bordered '>
                                                    <tbody>
                                                        <tr>
                                                            <td>Name</td>
                                                            <td className='text-capitalize'>{data.name ? data.name : '-'}</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Email</td>
                                                            <td className='text-capitalize'>{data.email ? data.email : '-'}</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Mobile</td>
                                                            <td className='text-capitalize'>{data.mobile ? data.mobile : '-'}</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Role</td>
                                                            <td className='text-capitalize'>{data ? data?.role?.name : '-'}</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Active</td>
                                                            <td className='text-capitalize'>{data.isActive ? 'true' : 'false'}</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Created At</td>
                                                            <td className='text-capitalize'>{data.createdAt ? data.createdAt : '-'}</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Updated At</td>
                                                            <td className='text-capitalize'>{data.updatedAt ? data.updatedAt : '-'}</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            {data.address && (
                                                <>
                                                    <div className='d-flex justify-content-between align-items-center my-3'>
                                                        <h5 className='my-3'>Address</h5>
                                                        <button onClick={() => { handleRedirct('editUserAddress') }} className='btn btn-outline-primary btn-sm'>
                                                            <i className='bi bi-pencil'></i> Edit
                                                        </button>
                                                    </div>
                                                    <div className='table-responsive'>
                                                        <table className='table table-bordered '>
                                                            <tbody>
                                                                <tr>
                                                                    <td>Building Name</td>
                                                                    <td>{data.address.buildingName ? data.address.buildingName : "-"}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Street</td>
                                                                    <td>{data.address.street ? data.address.street : "-"}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Area</td>
                                                                    <td>{data.address.area ? data.address.area : "-"}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>City</td>
                                                                    <td>{data.address.city ? data.address.city : "-"}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>State</td>
                                                                    <td>{data.address.state ? data.address.state : "-"}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Country</td>
                                                                    <td>{data.address.country ? data.address.country : "-"}</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>Pincode</td>
                                                                    <td>{data.address.pincode ? data.address.pincode : "-"}</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </>
                                            )
                                            }
                                        </div>
                                    </div>
                                )
                            }
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
};

export default UserList

import { useState } from "react";

const ToggleLink = ({submenu,title,isActive,link,handleActive})=>{
    const [toggleArrow, setToggleArrow] = useState(false);
    return (
        // <li className={`menu-item ${toggleArrow ? "open" : ""} ${isActive === link ? 'active' : ''}`}>
        <li className={`menu-item ${isActive === link ? 'open active menu-item-animating' : ''}`}>
            <button onClick={() => {
                setToggleArrow(!toggleArrow);
                handleActive(link)
            }} className="menu-link menu-toggle">
                <i className="menu-icon tf-icons bx bx-layout"></i>
                <div data-i18n="Layouts">{title}</div>
            </button>
            {submenu}
        </li>
    )
}

export default ToggleLink;
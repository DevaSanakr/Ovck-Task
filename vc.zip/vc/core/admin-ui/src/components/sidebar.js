import React, { useState } from "react";
import logo from '../logo.png'
import ToggleLink from "./toggleLink";
const Sidebar = () => {
    const[isActive,setIsActive] = useState('ds');
    const handleActive = (link)=>{
        // document.querySelector('.active').classList.remove('active');    
        setIsActive(link)
    }
    
    return (
        <aside id="layout-menu" className="layout-menu menu-vertical menu bg-menu-theme">
            <div className="app-brand demo">
                <a href="index.html" className="app-brand-link">
                    <span className="app-brand-logo demo">
                        <img src={logo} className="rounded-circle" alt="logo" />
                    </span>
                    <span className="app-brand-text demo menu-text fw-bolder ms-2">Sidharagasiyam</span>
                </a>

                <a href="/" onClick={(e) => {
                    e.preventDefault()
                    document.getElementsByTagName('html')[0].classList.remove('layout-menu-expanded')
                }} className="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
                    <i className="bx bx-chevron-left bx-sm align-middle"></i>
                </a>
            </div>

            <div className="menu-inner-shadow"></div>

            <ul className="menu-inner py-1">
                <li className={`menu-item ${isActive === 'ds' ? 'active' : ''}`} onClick={()=>{handleActive('ds')}} >
                    <a href="/dashboard" className="menu-link">
                        <i className="menu-icon tf-icons bx bx-home-circle"></i>
                        <div data-i18n="Analytics">Dashboard</div>
                    </a>
                </li>
                <ToggleLink
                    isActive= {isActive} 
                    link="users"
                    handleActive={handleActive}
                    submenu={
                        <ul className="menu-sub">
                            <li className="menu-item">
                                <a href="/userlist" className="menu-link">
                                    <div>Create</div>
                                </a>
                            </li>
                            <li className="menu-item">
                                <a href="/userlist" className="menu-link">
                                    <div data-i18n="Without navbar">List</div>
                                </a>
                            </li>
                        </ul>
                    }
                    title="Users"
                />
                <ToggleLink
                    isActive= {isActive} 
                    link="catalog"
                    handleActive={handleActive}
                    submenu={
                        <ul className="menu-sub">
                            <li className="menu-item">
                                <a href="/" className="menu-link">
                                    <div>Without menu</div>
                                </a>
                            </li>
                            <li className="menu-item">
                                <a href="/" className="menu-link">
                                    <div data-i18n="Without navbar">Without navbar</div>
                                </a>
                            </li>
                        </ul>
                    }
                    title="Catalog"
                />
            </ul>
        </aside>
    )
};

export default Sidebar;
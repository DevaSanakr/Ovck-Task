import axios from 'axios'
import React from 'react'
import SuccessModel from './successModel'

function DeleteModel({id}) {
    const deleteUser=()=>{
        axios.delete(`${process.env.REACT_APP_API_URL}/api/v1/auth/admin/user/${id}`)
        .then(res=>{
            console.log(res);
            document.getElementById('successBtn').click();
        }).catch(err=>console.log(err))
    }
    return (
        <>
            <div className="modal fade" id="deleteModal" tabIndex="-1" aria-labelledby="deleteModalLabel"
                aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered modal-sm" role="document">
                    <div className="modal-content border-0 rounded-3 shadow">
                        <div className="modal-body text-center py-5">
                            <i className="bi bi-info-circle fs-3 text-primary mb-2"></i>
                            <p className=''>Do you wish to <span className='fw-bold'>delete</span> this user <span className='fw-bold'>permanently?</span></p>
                            <div className="">
                                <button className='btn btn-light me-2 px-4' data-bs-dismiss="modal">Cancel</button>
                                <button className='btn btn-danger px-4' onClick={deleteUser} data-bs-dismiss="modal">Delete</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button type="button" className="d-none" id='successBtn' data-bs-toggle="modal" data-bs-target="#successModal"></button>
            <SuccessModel message={'This user has been deleted successfully'}/>
        </>
    )
}

export default DeleteModel

import React from 'react'
import checkCircle from '../assets/icons/check-circle.svg';
function SuccessModel({message}) {
    return (
        <>
            <div className="modal fade" id="successModal" tabIndex="-1" aria-labelledby="successModalLabel"
                aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered modal-sm" role="document">
                    <div className="modal-content border-0 rounded-3 shadow">
                        <div className="modal-body text-center py-5">
                            <img src={checkCircle} width="40px" className="mb-3" alt="" />
                            <p className='text-dark fs-5'>{message}</p>
                            <div className="">
                                <a href='/userlist' className='btn btn-sm btn-primary'>OK</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </>
    )
}

export default SuccessModel

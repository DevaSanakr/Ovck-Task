import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'

function BreadCrumb({navigation}) {
    const [navigations, setNavigations] = useState([]);
    const navigate = useNavigate();
    const handleNavigation = (link = "") => {
        navigate(link)
    }
    useEffect(()=>{
        setNavigations(navigation)
        // eslint-disable-next-line
    },[navigations])
    return (
        <>
            <div className="breadcrumb-block">
                <div className="breadcrumb">
                    {navigations && navigations.map((navigation, index) => (

                        <div
                            key={index}
                            className={index !== navigations.length - 1 ? 'breadcrumb-title-minor' : 'breadcrumb-title-major'}
                            onClick={() => index !== navigations.length - 1 && handleNavigation(navigation.link)}>
                            {navigation.title}
                            {index !== navigations.length - 1 && <p className="breadcrumb-icon">&gt;</p>}
                        </div>
                    ))}
                </div>
            </div>
        </>
    )
}

export default BreadCrumb
